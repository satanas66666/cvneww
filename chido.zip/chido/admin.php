<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// 🔴 LOGOUT PRIMERO (ANTES DE TODO)
if (isset($_GET['logout'])) {
    session_unset();      // limpia variables
    session_destroy();    // destruye sesión
    header("Location: login.php");
    exit;
}

// 🔒 PROTEGER PANEL
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

// =========================
// VPS CONFIG
// =========================
$vpsFile = __DIR__ . "/vps.json";

if (!file_exists($vpsFile)) {
    file_put_contents($vpsFile, "[]");
}

$VPS_DATA = json_decode(file_get_contents($vpsFile), true);

if (!is_array($VPS_DATA)) {
    $VPS_DATA = [];
    file_put_contents($vpsFile, "[]");
}

// SOLO URLs VÁLIDAS
$VPS = [];

foreach ($VPS_DATA as $v) {
    if (!empty($v['url'])) {
        $VPS[] = trim($v['url']);
    }
}

$TOKEN = "ULTRA_SECRET_TOKEN";

// =========================
// ENVIAR A TODAS LAS VPS
// =========================
function enviarVPS($data, $VPS, $TOKEN, $debug = false){

    $resultados = [];

    foreach ($VPS as $url){

        $url = trim($url);

        if (empty($url)) {
            continue;
        }

        $payload = json_encode(array_merge($data, [
            "token" => $TOKEN
        ]));

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($ch);
        $error    = curl_error($ch);
        $errno    = curl_errno($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        $ok = ($errno === 0 && $httpCode >= 200 && $httpCode < 300 && trim((string)$response) !== "");

        $resultados[] = [
            "url" => $url,
            "ok" => $ok,
            "http" => $httpCode,
            "response" => trim((string)$response),
            "error" => $error
        ];

        if ($debug) {
            echo "<b>Enviando a:</b> " . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . "<br>";
            echo "<b>Payload:</b> " . htmlspecialchars($payload, ENT_QUOTES, 'UTF-8') . "<br>";

            if ($ok) {
                echo "✅ Respuesta: " . htmlspecialchars((string)$response, ENT_QUOTES, 'UTF-8') . "<br>";
            } else {
                echo "❌ Error HTTP: " . htmlspecialchars((string)$httpCode, ENT_QUOTES, 'UTF-8') . "<br>";
                echo "❌ CURL: " . htmlspecialchars((string)$error, ENT_QUOTES, 'UTF-8') . "<br>";
                echo "❌ Respuesta: " . htmlspecialchars((string)$response, ENT_QUOTES, 'UTF-8') . "<br>";
            }

            echo "<hr>";
        }
    }

    return $resultados;
}

// =========================
// FUNCIONES AUXILIARES PRO
// =========================
function limpiarTempLocal($user){
    $tempFile = "/etc/vpn_temp_users";

    if (!file_exists($tempFile)) {
        return;
    }

    $lines = file($tempFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $new = [];

    foreach ($lines as $line) {
        if (strpos($line, $user . "|") !== 0) {
            $new[] = $line;
        }
    }

    file_put_contents($tempFile, count($new) ? implode("
", $new) . "
" : "");
}

function h($txt){
    return htmlspecialchars((string)$txt, ENT_QUOTES, 'UTF-8');
}

// =========================
// PASSWORD GLOBAL
// =========================

$PASS_DIR  = "/etc/SSHPlus";
$PASS_FILE = $PASS_DIR . "/global_pass";

if (!file_exists($PASS_DIR)) {
    mkdir($PASS_DIR, 0755, true);
}

if (!file_exists($PASS_FILE)) {
    file_put_contents($PASS_FILE, "satanas666");
    chmod($PASS_FILE, 0600);
}

$GLOBAL_PASS = trim(@file_get_contents($PASS_FILE));

if (empty($GLOBAL_PASS)) {
    $GLOBAL_PASS = "satanas666";
    file_put_contents($PASS_FILE, $GLOBAL_PASS);
    chmod($PASS_FILE, 0600);
}

// =========================
// CAMBIAR PASSWORD GLOBAL
// =========================

if (isset($_POST['change_pass'])) {

    $newpass = trim($_POST['newpass']);

    if (!empty($newpass)) {

        file_put_contents($PASS_FILE, $newpass);
        chmod($PASS_FILE, 0600);

        $GLOBAL_PASS = $newpass;
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// =========================
// AGREGAR VPS PRO
// =========================
if (isset($_POST['add_vps'])) {

    $url  = trim($_POST['vps_url']);
    $name = trim($_POST['vps_name']);

    if (!empty($url)) {

        $url = rtrim($url, "/");

        if (substr($url, -8) !== "/api.php") {
            $url .= "/api.php";
        }

        if (!preg_match('/^https?:\/\//', $url)) {
            $url = "http://" . $url;
        }

        $exists = false;

        foreach ($VPS_DATA as $v) {
            if (($v['url'] ?? '') === $url) {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $VPS_DATA[] = [
                "url" => $url,
                "name" => $name ?: "VPS " . (count($VPS_DATA) + 1)
            ];

            file_put_contents($vpsFile, json_encode($VPS_DATA, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }
    }

    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// =========================
// ELIMINAR VPS PRO
// =========================
if (isset($_GET['del_vps'])) {

    $url = trim($_GET['del_vps']);

    $VPS_DATA = array_values(array_filter($VPS_DATA, function($v) use ($url) {
        return ($v['url'] ?? '') !== $url;
    }));

    file_put_contents($vpsFile, json_encode($VPS_DATA, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// =========================
// ESTADO VPS (AJAX)
// =========================
if (isset($_GET['check_vps'])) {

    header("Content-Type: application/json");

    $result = [];

    foreach ($VPS_DATA as $v) {

        $url = $v['url'] . "?ping=1";

        $start = microtime(true);

        $ctx = stream_context_create([
            "http" => [
                "timeout" => 2
            ]
        ]);

        $res = @file_get_contents($url, false, $ctx);

        $time = round((microtime(true) - $start) * 1000);

        // 🔥 FIX CLAVE (AQUÍ)
        $res = trim((string)$res);

        $result[] = [
            "name" => $v['name'],
            "url" => $v['url'],
            "status" => ($res === "pong") ? "online" : "offline",
            "ping" => ($res === "pong") ? $time : null
        ];
    }

    echo json_encode($result);
    exit;
}

// =========================
// AJAX BLOQUEAR / DESBLOQUEAR
// =========================
if (isset($_GET['ajax'])) {

// 🔥 FIX PRO (NO CAMBIA TU LÓGICA)
    if (ob_get_level()) ob_clean();
    header("Content-Type: text/plain");

    // =====================
    // BLOQUEAR
    // =====================
    if (isset($_GET['block'])) {

        $user = preg_replace('/[^a-zA-Z0-9._-]/', '', $_GET['block']);
        if (empty($user)) {
            echo "error";
            exit;
        }

        // 📁 asegurar carpeta
        if (!file_exists("/etc/SSHPlus/blocked")) {
            mkdir("/etc/SSHPlus/blocked", 0777, true);
        }

        $uArg = escapeshellarg($user);

        // 🔒 BLOQUEO COMPLETO (CON SUDO)
        $r1 = shell_exec("sudo usermod -L $uArg 2>&1");
        $r2 = shell_exec("sudo usermod -s /bin/false $uArg 2>&1");

        // 💣 MATAR SESIONES
        shell_exec("sudo pkill -KILL -u $uArg 2>/dev/null");
        shell_exec("sudo killall -u $uArg 2>/dev/null");

        // 📁 MARCAR BLOQUEADO
        file_put_contents("/etc/SSHPlus/blocked/$user", "blocked");

        // 🔄 ENVIAR A VPS
        enviarVPS([
            "accion" => "bloquear",
            "user" => $user
        ], $VPS, $TOKEN);

        // ✅ VALIDAR RESULTADO
        if (strpos($r1, "usermod") !== false || strpos($r2, "usermod") !== false) {
            echo "error";
        } else {
            echo "blocked";
        }

        exit;
    }

    // =====================
    // DESBLOQUEAR
    // =====================
    if (isset($_GET['unlock'])) {

        $user = preg_replace('/[^a-zA-Z0-9._-]/', '', $_GET['unlock']);
        if (empty($user)) {
            echo "error";
            exit;
        }

        $uArg = escapeshellarg($user);

        // 🔓 DESBLOQUEAR (CON SUDO)
        $r1 = shell_exec("sudo usermod -U $uArg 2>&1");
        $r2 = shell_exec("sudo usermod -s /bin/bash $uArg 2>&1");

        // 🧹 LIMPIAR BLOQUEO
        @unlink("/etc/SSHPlus/blocked/$user");

        // 🔄 ENVIAR A VPS
        enviarVPS([
            "accion" => "desbloquear",
            "user" => $user
        ], $VPS, $TOKEN);

        // ✅ VALIDAR RESULTADO
        if (strpos($r1, "usermod") !== false || strpos($r2, "usermod") !== false) {
            echo "error";
        } else {
            echo "unlocked";
        }

        exit;
    }

    echo "error";
    exit;
}

// =========================
// FUNCIONES
// =========================
function getExpire($user) {
    $out = shell_exec("chage -l $user 2>/dev/null | grep 'Account expires'");
    if (!$out) return "N/A";
    $f = explode(':', $out);
    return trim($f[1]);
}

// =========================
// RESET ABUSOS GLOBAL
// =========================
if (isset($_GET['resetabuse'])) {
    $user = preg_replace('/[^a-zA-Z0-9._-]/', '', $_GET['resetabuse']);

    if (!empty($user)) {
        @unlink("/etc/SSHPlus/abuse/$user");
        @unlink("/etc/SSHPlus/abuse/{$user}_temp_count");
        @unlink("/etc/SSHPlus/warnings/$user");
        @unlink("/etc/SSHPlus/temp_block/$user");

        enviarVPS([
            "accion" => "reset_abuse",
            "user" => $user
        ], $VPS, $TOKEN);
    }

    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// =========================
// PUERTO CHECKUSER
// =========================
if (isset($_POST['change_port'])) {
    $msg = "ℹ️ El CheckUser ahora trabaja por api-vps en el puerto 8888. No se recomienda cambiarlo desde el panel.";
}
// =========================
// LIMPIAR EXPIRADOS MANUAL (GLOBAL)
// =========================
if (isset($_POST['clean_expired'])) {

    // 🔥 VPS PRINCIPAL
    shell_exec("/root/expire_clean.sh");

    // 🔥 VPS SECUNDARIAS
    enviarVPS([
        "accion" => "limpiar_expirados"
    ], $VPS, $TOKEN);

    header("Location: ".$_SERVER['REQUEST_URI']);
    exit;
}

// =========================
// CREAR USUARIO (NORMAL + TEMPORAL)
// =========================
if (isset($_POST['newuser'])) {

    $userRaw = preg_replace('/[^a-zA-Z0-9._-]/', '', $_POST['user']);
    if (empty($userRaw)) {
        header("Location: ".$_SERVER['REQUEST_URI']);
        exit;
    }
    $u = escapeshellarg($userRaw);

    // 🔐 PASSWORD GLOBAL
    $passRaw = $GLOBAL_PASS;
    $p = escapeshellarg($passRaw);

    // 🔽 NUEVO: TIPO DE USUARIO
    $tipo = isset($_POST['tipo']) ? $_POST['tipo'] : "normal";

    // 🔽 TIEMPO (días o minutos)
    $tiempo = ($tipo == "temporal") 
    ? intval($_POST['tiempo']) 
    : intval($_POST['days']);

    // ✅ LIMITE DINÁMICO
    $limit = isset($_POST['limite']) ? intval($_POST['limite']) : 3;

    // CREAR USUARIO SI NO EXISTE
    shell_exec("id $u >/dev/null 2>&1 || useradd -M -s /bin/false $u");

    // 🔐 PASSWORD SEGURA
    shell_exec("echo " . escapeshellarg($userRaw . ":" . $passRaw) . " | chpasswd");

    // =========================
    // 🧠 LÓGICA INTELIGENTE
    // =========================
    if ($tipo == "normal") {

        // 👉 EXPIRACIÓN POR DÍAS (como ya tienes)
        limpiarTempLocal($userRaw);
        shell_exec("chage -E $(date -d '+$tiempo days' +%Y-%m-%d) $u");

    } else {

        // 👉 TEMPORAL (MINUTOS)
        $expira = time() + ($tiempo * 60);

        // CREAR ARCHIVO SI NO EXISTE
        if (!file_exists("/etc/vpn_temp_users")) {
            file_put_contents("/etc/vpn_temp_users", "");
        }

        // GUARDAR USUARIO TEMPORAL SIN DUPLICADOS
        $lineas = file("/etc/vpn_temp_users", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $nuevas = [];

        foreach ($lineas as $linea) {
            $partes = explode("|", trim($linea));
            if (count($partes) >= 2 && trim($partes[0]) !== $userRaw) {
                $nuevas[] = $linea;
            }
        }

        $nuevas[] = "$userRaw|$expira";
        file_put_contents("/etc/vpn_temp_users", implode("\n", $nuevas) . "\n");
    }

    // =========================
    // 📁 LIMITES (SIN CAMBIOS)
    // =========================
    if (!file_exists("/etc/SSHPlus/limits")) {
        mkdir("/etc/SSHPlus/limits", 0777, true);
    }

    file_put_contents("/etc/SSHPlus/limits/$userRaw", $limit);

    // =========================
    // 🌐 ENVIAR A VPS (MEJORADO)
    // =========================
    enviarVPS([
        "accion" => "crear",
        "user" => $userRaw,
        "pass" => $passRaw,
        "tipo" => $tipo,          // 🔥 nuevo
        "tiempo" => $tiempo,      // 🔥 nuevo
        "limite" => $limit
    ], $VPS, $TOKEN);

    header("Location: ".$_SERVER['REQUEST_URI']);
    exit;
}

// =========================
// ELIMINAR (NORMAL + AJAX)
// =========================
if (isset($_GET['del']) || isset($_GET['auto_del'])) {

    // 🔥 detectar origen
    $isAjax = isset($_GET['auto_del']);

    $user = $isAjax ? $_GET['auto_del'] : $_GET['del'];

    // 🔒 Validación segura
    if (!preg_match('/^[a-zA-Z0-9._-]+$/', $user)) {
        echo $isAjax ? "error" : "Usuario inválido";
        exit;
    }

    $u = escapeshellarg($user);

    // 🔴 matar sesiones activas
    shell_exec("pkill -u $u 2>/dev/null");
    shell_exec("killall -u $u 2>/dev/null");

    // 🔴 eliminar usuario
    shell_exec("userdel -f $u 2>/dev/null");

    // 🧹 limpiar archivos
    @unlink("/etc/SSHPlus/limits/$user");
    @unlink("/etc/SSHPlus/blocked/$user");
    @unlink("/etc/SSHPlus/abuse/$user");

    // 🔥 LIMPIAR TEMPORALES (IMPORTANTE)
    if (file_exists("/etc/vpn_temp_users")) {
        $lines = file("/etc/vpn_temp_users");
        $new = "";

        foreach ($lines as $line) {
            if (strpos($line, $user . "|") !== 0) {
                $new .= $line;
            }
        }

        file_put_contents("/etc/vpn_temp_users", $new);
    }

    // 🔄 sincronizar VPS
    enviarVPS([
        "accion" => "eliminar",
        "user" => $user
    ], $VPS, $TOKEN);

    // 🔥 respuesta para AJAX
    if ($isAjax) {
        echo "ok";
        exit;
    }

    // 🔁 modo normal (panel)
  //  header("Location: ".$_SERVER['PHP_SELF']."?key=$PASS");
      header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// =========================
// EDITAR USUARIO
// =========================
if (isset($_POST['edituser'])) {

    $editName = preg_replace('/[^a-zA-Z0-9._-]/', '', $_POST['edit_name'] ?? '');

    if (empty($editName)) {
        header("Location: ".$_SERVER['REQUEST_URI']);
        exit;
    }

    $user = escapeshellarg($editName);
    $addDays = isset($_POST['add_days']) ? intval($_POST['add_days']) : 0;
    $setDate = trim($_POST['set_date'] ?? '');
    $tempMinutes = isset($_POST['edit_minutes']) ? intval($_POST['edit_minutes']) : 0;

    // PRIORIDAD 1: convertir o extender como temporal por minutos
    if ($tempMinutes > 0) {

        $expira = time() + ($tempMinutes * 60);

        if (!file_exists("/etc/vpn_temp_users")) {
            file_put_contents("/etc/vpn_temp_users", "");
        }

        limpiarTempLocal($editName);
        file_put_contents("/etc/vpn_temp_users", "$editName|$expira
", FILE_APPEND);

        enviarVPS([
            "accion" => "editar",
            "user" => $editName,
            "tipo" => "temporal",
            "tiempo" => $tempMinutes,
            "dias" => 0,
            "fecha" => ""
        ], $VPS, $TOKEN);

    } else {

        // Si se edita por días o fecha, deja de ser temporal
        if ($addDays > 0 || !empty($setDate)) {
            limpiarTempLocal($editName);
        }

        if ($addDays > 0) {

            $raw = shell_exec("chage -l $user 2>/dev/null | grep 'Account expires'");
            $fecha_actual = "";

            if ($raw) {
                $parts = explode(":", $raw);
                $fecha_actual = trim($parts[1]);
            }

            if ($fecha_actual == "" || strtolower($fecha_actual) == "never") {
                $base = time();
            } else {
                $base = strtotime($fecha_actual);
            }

            if ($base < time()) {
                $base = time();
            }

            $nueva_fecha = strtotime("+$addDays days", $base);
            $formato = date("Y-m-d", $nueva_fecha);
            shell_exec("chage -E " . escapeshellarg($formato) . " $user");
        }

        if (!empty($setDate)) {
            $date = escapeshellarg($setDate);
            shell_exec("chage -E $date $user");
        }

        enviarVPS([
            "accion" => "editar",
            "user" => $editName,
            "dias" => $addDays,
            "fecha" => $setDate
        ], $VPS, $TOKEN);
    }

    header("Location: ".$_SERVER['REQUEST_URI']);
    exit;
}

// =========================
// OBTENER USUARIOS
// =========================
$users = explode("\n", trim(shell_exec("awk -F: '$3>=1000 {print $1}' /etc/passwd")));

// =========================
// OBTENER PUERTO ACTUAL
// =========================
$current_port = "8888";
?>

<!DOCTYPE html>
<html>
<head>
<title>Panel PRO</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

body{
    background:#0f172a;
    color:white;
    font-family:sans-serif;
    scroll-behavior:smooth;
}

h2{margin-bottom:10px}

/* =========================
   INPUTS PRO (FIX REAL)
========================= */
input{
    padding:10px;
    border-radius:8px;
    border:1px solid #1e293b;
    background:#020617 !important;
    color:#e5e7eb !important;
    outline:none;
    -webkit-text-fill-color:#e5e7eb !important; /* 🔥 FIX ANDROID */
}

/* focus */
input:focus{
    border-color:#3b82f6;
    color:#ffffff !important;
    -webkit-text-fill-color:#ffffff !important;
}

/* placeholder */
input::placeholder{
    color:#9ca3af !important;
    opacity:1;
}

/* 🔥 AUTOFILL FIX (EL PROBLEMA REAL) */
input:-webkit-autofill,
input:-webkit-autofill:hover,
input:-webkit-autofill:focus{
    -webkit-box-shadow:0 0 0 1000px #020617 inset !important;
    -webkit-text-fill-color:#e5e7eb !important;
    transition: background-color 9999s ease-in-out 0s;
}

/* =========================
   BOTONES BASE
========================= */
button{
    border:none;
    cursor:pointer;
}

button, a{
    transition:0.2s;
    text-decoration:none;
}

button:hover, a:hover{
    transform:scale(1.05);
}

button:active, a:active{
    transform:scale(0.95);
}

/* =========================
   CONTENEDOR BOTONES PRO
========================= */
.acciones{
    text-align:center;
}

.btn-group{
    display:flex;
    gap:6px;
    justify-content:center;
    align-items:center;
    flex-wrap:wrap;
}

/* BOTONES UNIFICADOS */
.btn-group button,
.btn-group a{
    height:38px;
    padding:0 10px;
    border-radius:8px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:13px;
    white-space:nowrap;
    min-width:90px;
    font-weight:500;
}

/* =========================
   COLORES PRO
========================= */
.btn-create{
    background: linear-gradient(135deg,#22c55e,#16a34a);
    color:white;

    width:100%;
    padding:14px;
    font-size:15px;
    border-radius:10px;

    display:block;
    text-align:center;
}

.btn-edit{
    background:linear-gradient(135deg,#3b82f6,#2563eb);
    color:white;
}

.btn-toggle{
    background:linear-gradient(135deg,#facc15,#eab308);
    color:black;
}

/* 🔥 CAMBIO DINÁMICO */
.btn-toggle[data-status="blocked"]{
    background:linear-gradient(135deg,#ef4444,#dc2626);
    color:white;
}

.btn-toggle[data-status="active"]{
    background:linear-gradient(135deg,#22c55e,#16a34a);
    color:white;
}

.btn-reset{
    background:linear-gradient(135deg,#22c55e,#16a34a);
    color:white;
}

.btn-del{
    background:linear-gradient(135deg,#ef4444,#dc2626);
    color:white;
}

/* =========================
   TABLA
========================= */
table{
    width:100%;
    border-collapse:collapse;
    border-radius:10px;
    overflow:hidden;
}

th,td{
    padding:10px;
    border-bottom:1px solid #1e293b;
}

tr{
    transition:0.2s;
}

tr:hover{
    background:#1e293b;
}

th{
    color:#94a3b8;
    font-weight:500;
}

/* =========================
   ESTADOS (IMPORTANTE JS)
========================= */
.estado{
    font-weight:bold;
}

.estado-activo{
    color:#22c55e;
}

.estado-bloqueado{
    color:#ef4444;
}

/* =========================
   BUSCADOR
========================= */
#buscador{
    background:#020617;
    border:1px solid #1e293b;
    color:white;
    padding:10px;
    border-radius:10px;
}

/* =========================
   MODAL
========================= */
.modal{
    display:none;
    position:fixed;
    top:0;left:0;
    width:100%;height:100%;
    background:rgba(0,0,0,0.6);
}

.modal-content{
    background:#1e293b;
    padding:20px;
    margin:10% auto;
    width:300px;
    border-radius:10px;
}

/* =========================
   CARD PRO
========================= */
.card{
    background:linear-gradient(145deg,#0f172a,#111827);
    padding:15px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.4);
}

/* =========================
   RESPONSIVE
========================= */
@media(max-width:768px){

    .btn-group{
        gap:4px;
    }

    .btn-group button,
    .btn-group a{
        font-size:11px;
        height:34px;
        padding:0 8px;
    }

    input{
        width:100%;
    }

}

/* 🔥 animación eliminación suave */
.fade-out{
    opacity:0;
    transform:scale(0.95);
    transition:0.4s ease;
}

/* =========================
   🔥 DASHBOARD LAYOUT PRO
========================= */

/* RESET */
body{
    margin:0;
}

/* CONTENEDOR PRINCIPAL */
.layout{
    display:flex;
}

/* SIDEBAR */
.sidebar{
    width:220px;
    background:#020617;
    height:100vh;
    padding:20px;
    position:fixed;
    left:0;
    top:0;
    border-right:1px solid #1e293b;
}

.sidebar h2{
    font-size:18px;
    margin-bottom:20px;
    color:#38bdf8;
}

/* LINKS SIDEBAR */
.sidebar a{
    display:block;
    padding:10px;
    margin-bottom:5px;
    border-radius:8px;
    color:#94a3b8;
    cursor:pointer;
    transition:0.2s;
}

.sidebar a:hover,
.sidebar a.active{
    background:#0ea5e9;
    color:white;
}

/* USUARIO ABAJO */
.user-box{
    position:absolute;
    bottom:20px;
    left:20px;
    right:20px;
    font-size:13px;
}

/* CONTENIDO */
.main{
    margin-left:240px;
    padding:20px;
    width:100%;
}

/* TOP BAR */
.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

/* soporta h1 o h2 sin romper nada */
.topbar h1,
.topbar h2{
    margin:0;
    font-size:22px;
}

/* BOTÓN LOGOUT (FIX REAL) */
.btn-logout{
    /* ❌ quitamos fixed (era el problema) */
    position: relative;

    background: #ef4444;
    color: #ffffff;
    padding: 10px 14px;
    border-radius: 10px;
    font-size: 13px;
    text-decoration: none;

    box-shadow: 0 5px 15px rgba(0,0,0,0.4);

    display: inline-block;
    white-space: nowrap;

    transition: 0.2s ease;
}

/* hover pro */
.btn-logout:hover{
    transform: scale(1.05);
    background: #dc2626;
}

/* click */
.btn-logout:active{
    transform: scale(0.95);
}

/* base */
body{
    margin: 0;
}

/* GRID STATS */
.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:15px;
    margin-bottom:20px;
}

/* TARJETAS MÁS PRO */
.card{
    backdrop-filter:blur(10px);
    border:1px solid #1e293b;
}

/* RESPONSIVE SIDEBAR */
@media(max-width:768px){

    .sidebar{
        width:180px;
    }

    .main{
        margin-left:190px;
    }
}


</style>


<script>
function openEdit(user){
    document.getElementById("editUser").value = user;
    document.getElementById("modal").style.display="block";
}
function closeModal(){
    document.getElementById("modal").style.display="none";
}

// 🔍 BUSCADOR
function buscarUsuario() {
    let filtro = document.getElementById("buscador").value.toLowerCase();
    let filas = document.querySelectorAll("table tr");

    filas.forEach((fila, index) => {
        if (index === 0) return;

        let texto = fila.innerText.toLowerCase();

        if (texto.includes(filtro)) {
            fila.style.display = "";
        } else {
            fila.style.display = "none";
        }
    });
}
</script>

</head>
<body>

<div class="topbar">
    <h2>🔥 Panel SpeicersPRO VPN</h2>
    <a href="logout.php" class="btn-logout">Cerrar sesión</a>
</div>

<?php
$total = 0;
foreach ($users as $u) {
    if (in_array($u, ["nobody","root","daemon"])) continue;
    if (strlen($u) > 2) $total++;
}

?>
<!-- ========================= -->
<!-- 🔥 MONITOR DE VPS -->
<!-- ========================= -->

<div class="card" style="margin-bottom:20px;">

<h3>🌐 Monitor VPS</h3>

<form method="POST" style="
display:grid;
grid-template-columns: 110px 1fr 50px;
gap:10px;
margin-bottom:10px;
align-items:center;
width:100%;
">

    <!-- NOMBRE VPS -->
    <input name="vps_name"
           placeholder="Nombre"
           required
           style="
           width:100%;
           background:#020617;
           color:#fff;
           border:1px solid #1e293b;
           border-radius:8px;
           padding:10px;">

    <!-- URL VPS -->
    <input name="vps_url"
           placeholder="http://IP:PUERTO/api.php"
           required
           style="
           width:100%;
           background:#020617;
           color:#22c55e;
           border:1px solid #22c55e;
           border-radius:10px;
           padding:12px;
           font-weight:bold;
           caret-color:#22c55e;">

    <!-- BOTÓN -->
    <button name="add_vps"
            class="btn-create"
            style="
            width:100%;
            height:45px;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:18px;">
        ➕
    </button>

</form>

<!-- LISTA VPS -->
<div id="vpsList"></div>

</div>


<!-- ========================= -->
<!-- 🔥 TARJETA USUARIOS -->
<!-- ========================= -->
<div class="card stats-card">

    <!-- HEADER -->
    <div class="stats-header">
        <span class="stats-icon">👥</span>
        <span class="stats-text">Usuarios Totales</span>
        <span class="stats-count"><?= $total ?></span>
    </div>

    <!-- PASSWORD GLOBAL -->
    <div class="global-pass-box">
        🔐 Password global: 
        <b id="passText">••••••••</b>
        <button type="button" class="btn-eye" onclick="togglePass()">👁️</button>
    </div>

    <!-- CAMBIAR PASSWORD -->
    <form method="POST" class="form-pass" onsubmit="return confirm('¿Cambiar password global?')">
        <input type="text" name="newpass" placeholder="Nueva password" required>
        <button type="submit" name="change_pass" class="btn-pass">
            🔄 Actualizar
        </button>
    </form>

    <!-- LIMPIAR -->
    <form method="POST" onsubmit="return confirm('¿Eliminar usuarios expirados ahora?')">
        <button type="submit" name="clean_expired" class="btn-clean">
            🧹 Limpiar Expirados
        </button>
    </form>

</div>

<!-- ========================= -->
<!-- ➕ CREAR USUARIO -->
<!-- ========================= -->
<div class="card">

<h3>➕ Crear usuario</h3>

<form method="post" style="display:grid; grid-template-columns:1fr 1fr; gap:12px; width:100%;">

    <input name="user" placeholder="usuario" required style="width:100%;">

    <select name="tipo" id="tipo" style="width:100%;">
        <option value="normal">Normal (días)</option>
        <option value="temporal">Temporal (minutos)</option>
    </select>

    <input type="number" name="days" id="days" placeholder="días" min="1" style="width:100%;">
    <input type="number" name="tiempo" id="tiempo" placeholder="minutos" min="1" style="width:100%;">

    <input type="number" name="limite" placeholder="límite" value="3" min="1" required style="width:100%;">

    <button class="btn-create" name="newuser" 
    style="grid-column: span 2; width:100%; padding:14px; font-size:15px;">
        Crear usuario
    </button>

</form>

</div>

<!-- ========================= -->
<!-- 🌐 CHECKUSER -->
<!-- ========================= -->
<div class="card">

<h3>🌐 Configuración CheckUser</h3>

<p>Puerto actual: <b><?= $current_port ?></b></p>

<p style="color:#94a3b8;">El panel usa <b>api-vps</b> con rutas <b>/api.php</b> y <b>/checkUser</b>.</p>

<?php if(isset($msg)) echo "<p>$msg</p>"; ?>

</div>

<!-- ========================= -->
<!-- 🔍 BUSCADOR -->
<!-- ========================= -->
<div class="card">

<h3>🔍 Buscar usuario</h3>

<input type="text" id="buscador" onkeyup="buscarUsuario()" 
placeholder="Buscar usuario..." 
style="width:100%;">

</div>

<!-- ========================= -->
<!-- 📋 TABLA -->
<!-- ========================= -->
<div class="card">

<table>

<tr>
<th>User</th>
<th>Expira</th>
<th>Límite</th>
<th>Abusos</th>
<th>Tiempo restante</th> <!-- 🔥 NUEVO -->
<th>Estado</th>
<th>Acción</th>
</tr>

<?php
// =========================
// 🔥 LEER USUARIOS TEMPORALES
// =========================
$tempUsers = [];

if (file_exists("/etc/vpn_temp_users")) {
    $lines = file("/etc/vpn_temp_users");

    foreach ($lines as $line) {
        $parts = explode("|", trim($line));
        if (count($parts) >= 2) {
            $tu = trim($parts[0]);
            $exp = trim($parts[1]);
            if ($tu !== "" && is_numeric($exp)) {
                $tempUsers[$tu] = $exp;
            }
        }
    }
}

foreach ($users as $u) {

    if (strlen($u) < 3) continue;

    if (!posix_getpwnam($u)) continue;

    if (in_array($u, ["nobody","daemon","bin","sys"])) continue;

    $limit = @file_get_contents("/etc/SSHPlus/limits/$u");
    if (!$limit) $limit = "∞";
    
// =========================
// ⏱ TIEMPO RESTANTE (PRO REAL)
// =========================
$tiempoRestante = "<span style='color:#6b7280;'>—</span>";

if (isset($tempUsers[$u])) {

    $exp = (int)$tempUsers[$u]; // asegurar número
    $rest = $exp - time();

    if ($rest > 0) {

        // 🔥 AHORA INCLUYE USUARIO (CLAVE)
        $tiempoRestante = "<span class='timer' data-exp='$exp' data-user='$u'></span>";

    } else {
        $tiempoRestante = "<span style='color:#ef4444;'>🔴 Expirado</span>";
    }
}

    $abuse = @file_get_contents("/etc/SSHPlus/abuse/$u");
    if (!$abuse) $abuse = 0;

    $blocked = file_exists("/etc/SSHPlus/blocked/$u");

    $estado = $blocked
    ? "<span style='color:#ef4444;'>🔴 Bloqueado</span>"
    : "<span style='color:#22c55e;'>🟢 Activo</span>";

   echo "<tr>
  <td>$u</td>
  <td>".getExpire($u)."</td>
  <td>$limit</td>
  <td>$abuse</td>
  <td>$tiempoRestante</td>";

$blocked_file = "/etc/SSHPlus/blocked/$u";
$isBlocked = file_exists($blocked_file);

if ($isBlocked) {
    echo "<td class='estado estado-bloqueado'>● Bloqueado</td>";
} else {
    echo "<td class='estado estado-activo'>● Activo</td>";
}

echo "<td class='acciones'>

<div class='btn-group'>

<button class='btn-edit' onclick=\"openEdit('".$u."')\">
✏️ Editar
</button>

<button 
class='btn-toggle' 
onclick=\"toggleUser('".$u."', this)\" 
data-status='".($isBlocked ? "blocked" : "active")."'>
".($isBlocked ? "🔓 Desbloquear" : "🔒 Bloquear")."
</button>

<a href='?resetabuse=".urlencode($u)."' class='btn-reset'>
♻️ Reset
</a>

<a href='?del=".urlencode($u)."' class='btn-del'>
🗑️ Eliminar
</a>

</div>

</td>
</tr>";


}
?>

</table>
</div>

<!-- MODAL EDIT -->
<div id="modal" class="modal">
<div class="modal-content">

<h3>Editar usuario</h3>

<form method="post">
<input type="hidden" name="edit_name" id="editUser">

<label>Agregar días:</label><br>
<input name="add_days" placeholder="ej: 5"><br><br>

<label>Fecha exacta:</label><br>
<input type="date" name="set_date"><br><br>

<label>Temporal minutos:</label><br>
<input type="number" name="edit_minutes" placeholder="ej: 60"><br><br>

<button class="btn-edit" name="edituser">Guardar</button>
<button type="button" onclick="closeModal()">Cerrar</button>
</form>

</div>
</div>
<script>
document.querySelectorAll(".btn-del").forEach(btn => {
    btn.addEventListener("click", function(e){

        if(this.getAttribute("href")){
            e.preventDefault();

            if(confirm("¿Eliminar usuario?")){
                fetch(this.href)
                .then(() => location.reload());
            }
        }
    });
});
</script>

<script>
function toggleUser(user, btn){

    let status = btn.getAttribute("data-status");

    btn.innerHTML = "⏳...";
    btn.disabled = true;

    let action = (status === "blocked") ? "unlock" : "block";

    fetch(`?ajax=1&${action}=${user}`)
    .then(res => res.text())
    .then(data => {

        data = data.trim().toLowerCase(); // 🔥 ajuste mínimo

        let estadoCell = btn.closest("tr").querySelector(".estado");

        if(data.includes("blocked")){ // 🔥 cambio clave
            btn.innerHTML = "🔓 Desbloquear";
            btn.setAttribute("data-status", "blocked");

            if (estadoCell) {
                estadoCell.className = "estado estado-bloqueado";
                estadoCell.textContent = "● Bloqueado";
            }

        } else if(data.includes("unlocked")){ // 🔥 cambio clave
            btn.innerHTML = "🔒 Bloquear";
            btn.setAttribute("data-status", "active");

            if (estadoCell) {
                estadoCell.className = "estado estado-activo";
                estadoCell.textContent = "● Activo";
            }

        } else {
            btn.innerHTML = "❌ Error";
        }

        btn.disabled = false;

    })
    .catch(() => {
        btn.innerHTML = "❌ Error";
        btn.disabled = false;
    });
}
</script>

<!-- todo tu HTML -->

<script>
let visible = false;

function togglePass(){
    const el = document.getElementById("passText");

    if (!visible) {
        el.innerText = "<?= $GLOBAL_PASS ?>";
        visible = true;
    } else {
        el.innerText = "••••••••";
        visible = false;
    }
}
</script>

<script>
// =========================
// ⏱ CONTADOR EN VIVO REAL PRO
// =========================

// 🔒 evitar múltiples eliminaciones
let deletedUsers = new Set();

function formatTime(seconds){

    let d = Math.floor(seconds / 86400);
    let h = Math.floor((seconds % 86400) / 3600);
    let m = Math.floor((seconds % 3600) / 60);
    let s = seconds % 60;

    if (d > 0) return `🟡 ${d}d`;
    if (h > 0) return `🔵 ${h}h`;
    if (m > 0) return `🟢 ${m}m`;
    return `⏱ ${s}s`;
}

function updateTimers(){

    let now = Math.floor(Date.now() / 1000); // tiempo real

    document.querySelectorAll(".timer").forEach(el => {

        let exp  = parseInt(el.getAttribute("data-exp"));
        let user = el.getAttribute("data-user");

        if (!exp || !user) return;

        let rest = exp - now;

        if (rest <= 0){

            el.innerHTML = "🔴 Expirado";

            // 🔒 evitar múltiples llamadas
            if (!deletedUsers.has(user)) {

                deletedUsers.add(user);

                let row = el.closest("tr");

                // 🔥 eliminar en backend
                fetch(`?auto_del=${encodeURIComponent(user)}`)
                .then(res => res.text())
                .then(data => {

                    if (data.trim() === "ok") {

                        // ✨ animación suave (si tienes el CSS fade-out)
                        if (row){
                            row.classList.add("fade-out");

                            setTimeout(() => {
                                row.remove();
                            }, 400);
                        }

                    } else {
                        console.warn("Error eliminando usuario:", user);
                    }

                })
                .catch(err => {
                    console.error("Error AJAX:", err);
                });
            }

            return;
        }

        el.innerHTML = formatTime(rest);
    });
}

// ⏱ actualizar cada segundo
setInterval(updateTimers, 1000);
updateTimers();
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {

    const tipo = document.getElementById("tipo");
    const dias = document.getElementById("days");
    const tiempo = document.getElementById("tiempo");

    function toggleCampos() {

        if (tipo.value === "temporal") {

            tiempo.required = true;
            tiempo.style.display = "block";

            dias.required = false;
            dias.style.display = "none";
            dias.value = "";

        } else {

            dias.required = true;
            dias.style.display = "block";

            tiempo.required = false;
            tiempo.style.display = "none";
            tiempo.value = "";
        }
    }

    // 🔥 evento cambio
    tipo.addEventListener("change", toggleCampos);

    // 🔥 estado inicial al cargar
    toggleCampos();

});
</script>

<script>
function loadVPS(){

    fetch('?check_vps=1')
    .then(res => res.json())
    .then(data => {

        let html = '';

        data.forEach(v => {

            let color = v.status === "online" ? "#22c55e" : "#ef4444";
            let status = v.status === "online" ? "🟢 Online" : "🔴 Offline";

            html += `
            <div style="display:flex;justify-content:space-between;
                        background:#020617;padding:10px;margin-bottom:5px;
                        border-radius:8px;align-items:center;">

                <div>
                    <b>${v.name}</b><br>
                    <small>${v.url}</small>
                </div>

                <div style="text-align:right;">
                    <span style="color:${color}">${status}</span><br>
                    ${v.ping ? v.ping + " ms" : ""}
                </div>

                <a href="?del_vps=${encodeURIComponent(v.url)}"
                   onclick="return confirm('Eliminar VPS?')"
                   style="color:red;margin-left:10px;">
                   ❌
                </a>
            </div>
            `;
        });

        document.getElementById("vpsList").innerHTML = html;

    });
}

// 🔄 actualizar cada 5s
setInterval(loadVPS, 5000);
loadVPS();
</script>


</body>
</html>


