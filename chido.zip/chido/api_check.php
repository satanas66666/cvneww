<?php

header("Content-Type: application/json");

// 🔥 SOPORTE POST + GET (NO rompe tu app)
$data = json_decode(file_get_contents("php://input"), true);
$user = $data['user'] ?? ($_GET['user'] ?? '');

if (!$user) {
    echo json_encode([
        "status" => "error",
        "msg" => "No user"
    ]);
    exit;
}

// =========================
// VALIDAR EXISTENCIA
// =========================
$exists = shell_exec("id -u $user 2>/dev/null");

if (!$exists || trim($exists) == "") {
    echo json_encode([
        "status" => "invalid",
        "expire" => null,
        "days_left" => 0,
        "msg" => "Usuario no existe"
    ]);
    exit;
}

// =========================
// OBTENER EXPIRACIÓN
// =========================
$raw = shell_exec("chage -l $user 2>/dev/null");
$expire = "never";

foreach (explode("\n", $raw) as $line) {
    if (stripos($line, "Account expires") !== false) {
        $parts = explode(":", $line);
        $expire = trim($parts[1]);
        break;
    }
}

// =========================
// SIN EXPIRACIÓN
// =========================
if ($expire == "" || strtolower($expire) == "never") {
    echo json_encode([
        "status" => "ok",
        "expire" => "never",
        "days_left" => -1,
        "msg" => "Cuenta sin expiración"
    ]);
    exit;
}

// =========================
// VALIDAR FECHA
// =========================
$expTime = strtotime($expire);

// 🔥 FIX FECHAS BUG (año 0002 etc)
if ($expTime === false || $expTime <= time() - (86400 * 365 * 50)) {
    echo json_encode([
        "status" => "error",
        "expire" => $expire,
        "days_left" => 0,
        "msg" => "Fecha inválida"
    ]);
    exit;
}

$now = time();
$days = floor(($expTime - $now) / 86400);

// =========================
// RESPUESTA FINAL
// =========================
if ($now >= $expTime) {

    echo json_encode([
        "status" => "expired",
        "expire" => date("Y-m-d", $expTime),
        "days_left" => 0,
        "msg" => "Cuenta vencida"
    ]);

} else {

    echo json_encode([
        "status" => "ok",
        "expire" => date("Y-m-d", $expTime),
        "days_left" => $days,
        "msg" => "Activo"
    ]);
}

