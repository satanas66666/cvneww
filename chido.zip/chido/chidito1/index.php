<?php

$datos = file_get_contents("php://input");
$update = json_decode($datos, true);

$FORMATO = "dmY";
$ONLINE = "DIRECTO";

if (isset($update) && isset($update['user'])) {

    $userClean = trim($update['user']);
    $usuario = escapeshellarg($userClean);

    // =========================
    // VALIDAR USUARIO
    // =========================
    exec("id -u $usuario 2>/dev/null", $out, $code);

    if ($code !== 0) {
        echo "Not exist";
        exit;
    }

    // =========================
    // 🔒 VALIDACIÓN BLOQUEO
    // =========================

    if (file_exists("/etc/SSHPlus/blocked/$userClean")) {
        echo "Not exist";
        exit;
    }

    $lockCheck = shell_exec("passwd -S $usuario 2>/dev/null");

    if ($lockCheck && strpos($lockCheck, ' L ') !== false) {
        echo "Not exist";
        exit;
    }

    $shellCheck = shell_exec("getent passwd $usuario | cut -d: -f7");

    if ($shellCheck && strpos($shellCheck, 'nologin') !== false) {
        echo "Not exist";
        exit;
    }

    // =========================
    // ⏱ USUARIO TEMPORAL POR MINUTOS
    // =========================
    $tempFile = "/etc/vpn_temp_users";

    if (file_exists($tempFile)) {
        $lineas = file($tempFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        foreach ($lineas as $linea) {
            $partes = explode("|", trim($linea));

            if (count($partes) >= 2) {
                $usuarioTemp = trim($partes[0]);
                $expiraTemp = intval(trim($partes[1]));

                if ($usuarioTemp === $userClean) {

                    if ($expiraTemp <= time()) {
                        echo "Not exist";
                        exit;
                    }

                    echo "TEMP|" . $expiraTemp;
                    exit;
                }
            }
        }
    }

    // =========================
    // OBTENER FECHA NORMAL CHAGE
    // =========================
    $cmd = "chage -l $usuario | grep 'Account expires'";
    $datos = shell_exec($cmd);

    if (!$datos) {
        echo "Not exist";
        exit;
    }

    $fecha = explode(':', $datos);

    if (!isset($fecha[1])) {
        echo "Not exist";
        exit;
    }

    $rawDate = trim($fecha[1]);

    if (strtolower($rawDate) == "never") {
        echo "31122099";
        exit;
    }

    $date = date_create($rawDate);

    if (!$date) {
        echo "Not exist";
        exit;
    }

    $expTime = $date->getTimestamp();

    if (time() > $expTime) {
        echo "Not exist";
        exit;
    }

    echo date_format($date, $FORMATO);
    exit;

} else {

    // =========================
    // ONLINE USERS
    // =========================
    $ssh = shell_exec('ps -x | grep sshd | grep -v root | grep priv | wc -l');

    if (file_exists('/etc/openvpn/openvpn-status.log')) {
        $openvpn = shell_exec('grep -c "10.8.0" /etc/openvpn/openvpn-status.log');
    } else {
        $openvpn = "0";
    }

    if (file_exists('/etc/default/dropbear')) {
        $drp = shell_exec('ps aux | grep dropbear | grep -v grep | wc -l');
        $dropbear = $drp - 1;
    } else {
        $dropbear = "0";
    }

    $total = $ssh + $openvpn + $dropbear;

    switch ($ONLINE) {
        case 'DIRECTO':
            echo $total;
            break;

        case 'JSON':
            echo json_encode([
                "onlines" => $total,
                "limite" => "2500"
            ]);
            break;

        default:
            echo $total;
            break;
    }
}

exit();
?>
